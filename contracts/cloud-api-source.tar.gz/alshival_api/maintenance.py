import asyncio
import logging

from .config import Settings
from .domain import Domain
from .store import Store


async def reconcile(domain, store):
    pending = await domain.call("usage_pending")
    for row in pending["items"]:
        present = await store.batch_outcome(
            row["workspace_id"], row["id"], events=row["events"], size=row["bytes"]
        )
        if present is not None:
            await domain.call("usage_finish", id=row["id"], state="committed" if present else "released")


async def alerts(domain, store):
    from datetime import UTC, datetime
    from .store import stamp
    cursor = await domain.call('log_alert_start')
    rows = await store.alert_errors(stamp(datetime.fromisoformat(cursor['since'])))
    if rows:
        for row in rows:
            row['received_at'] = datetime.fromisoformat(row['received_at']).replace(tzinfo=UTC).isoformat()
        await domain.call('log_alert_observations', items=rows)
        await store.acknowledge_errors([row['id'] for row in rows])


async def main():
    settings = Settings()
    domain, store = Domain(settings), Store(settings)
    await store.initialize()
    from .usage import Outbox, rollup

    outbox = Outbox(settings.usage_path)
    while True:
        try:
            await alerts(domain, store)
        except Exception:
            logging.getLogger(__name__).warning('Persisted log alert scan unavailable; will retry')
        try:
            for _ in range(100):
                count = await outbox.flush(store)
                if count < 500:
                    break
            await rollup(store)
            await reconcile(domain, store)
            policies = await domain.call("policies")
            for policy in policies["items"]:
                await store.maintain(policy)
                retained = await store.retained(policy["workspace_id"], policy)
                await domain.call(
                    "usage_storage", workspace_id=policy["workspace_id"], stored_bytes=retained["stored_bytes"]
                )
        except Exception:
            logging.getLogger(__name__).exception("Log retention maintenance failed")
        await asyncio.sleep(60)


if __name__ == "__main__":
    asyncio.run(main())

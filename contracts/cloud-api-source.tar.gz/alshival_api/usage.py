"""Content-free request accounting. SQLite outbox survives worker/container restarts."""

import contextvars
import json
import sqlite3
import time
from datetime import UTC, datetime

from .errors import APIError
from .store import ZERO, stamp

context = contextvars.ContextVar("api_usage", default=None)

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS api_requests (
 request_id UUID, occurred_at DateTime64(6, 'UTC'), workspace_id UUID, key_id UUID,
 key_type LowCardinality(String), actor_id UInt64, audience LowCardinality(String),
 transport LowCardinality(String), method LowCardinality(String), route String,
 status UInt16, error_code LowCardinality(String), elapsed_ms UInt64, request_bytes UInt64,
 response_bytes UInt64, log_events UInt64, log_bytes UInt64, version UInt64
) ENGINE=ReplacingMergeTree(version) PARTITION BY toYYYYMMDD(occurred_at)
ORDER BY (workspace_id, occurred_at, request_id)
TTL toDateTime(occurred_at) + INTERVAL 90 DAY DELETE
SETTINGS fsync_after_insert=1, fsync_part_directory=1""",
    """CREATE TABLE IF NOT EXISTS api_daily (
 day Date, workspace_id UUID, key_id UUID, key_type LowCardinality(String), actor_id UInt64,
 audience LowCardinality(String), transport LowCardinality(String), requests UInt64,
 errors UInt64, request_bytes UInt64, response_bytes UInt64, log_events UInt64, log_bytes UInt64,
 version UInt64
) ENGINE=ReplacingMergeTree(version) PARTITION BY toYYYYMM(day)
ORDER BY (workspace_id, day, key_id, key_type, actor_id, audience, transport)
TTL day + INTERVAL 13 MONTH DELETE
SETTINGS fsync_after_insert=1, fsync_part_directory=1""",
]


class Outbox:
    def __init__(self, path):
        self.db = sqlite3.connect(path, timeout=3, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS requests (id TEXT PRIMARY KEY, updated REAL, done INTEGER, payload TEXT)"
        )
        self.db.commit()

    def save(self, row, done=False):
        try:
            if not done and self.db.execute("SELECT count(*) FROM requests").fetchone()[0] >= 250000:
                raise APIError(503, "accounting_backlog", "Usage accounting is catching up; retry later.", 30)
            with self.db:
                self.db.execute(
                    "INSERT INTO requests VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET updated=excluded.updated, done=excluded.done, payload=excluded.payload",
                    (row["request_id"], time.time(), int(done), json.dumps(row)),
                )
        except sqlite3.Error:
            raise APIError(503, "accounting_unavailable", "Usage accounting is unavailable; retry later.", 5) from None

    def close(self):
        self.db.close()

    def status(self):
        row = self.db.execute("SELECT count(*), min(updated) FROM requests").fetchone()
        return {"queued": row[0], "oldest_queued_at": row[1], "capacity": 250000}

    async def flush(self, store):
        # The same metadata retention applies during an analytics outage.
        with self.db:
            self.db.execute("DELETE FROM requests WHERE updated<?", (time.time() - 90 * 86400,))
        rows = self.db.execute(
            "SELECT id, updated, payload FROM requests WHERE done=1 OR updated<? ORDER BY updated LIMIT 500",
            (time.time() - 600,),
        ).fetchall()
        if not rows:
            return 0
        await store.sql("INSERT INTO api_requests FORMAT JSONEachRow", content="\n".join(r[2] for r in rows).encode())
        with self.db:
            self.db.executemany("DELETE FROM requests WHERE id=? AND updated=?", [(r[0], r[1]) for r in rows])
        return len(rows)


def new_row(identifier, method, transport):
    return {
        "request_id": identifier,
        "occurred_at": stamp(datetime.now(UTC)),
        "workspace_id": ZERO,
        "key_id": ZERO,
        "key_type": "unknown",
        "actor_id": 0,
        "audience": "unknown",
        "transport": transport,
        "method": method,
        "route": "unmatched",
        "status": 0,
        "error_code": "outcome_unknown",
        "elapsed_ms": 0,
        "request_bytes": 0,
        "response_bytes": 0,
        "log_events": 0,
        "log_bytes": 0,
        "version": time.time_ns(),
    }


def set_subject(value):
    state = context.get()
    if state:
        for name in ("workspace_id", "key_id", "key_type", "actor_id", "audience"):
            if name in value:
                state["row"][name] = value[name]
        if state["durable"]:
            state["outbox"].save(state["row"])


def visibility_filter(view):
    params = {"ws": view["workspace_id"], "actor": view.get("actor_id") or 0}
    where = "workspace_id={ws:UUID}"
    if not view.get("staff"):
        if view.get("own_personal_only"):
            where += " AND key_type='personal' AND actor_id={actor:UInt64}"
        else:
            where += " AND audience='customer' AND (key_type!='personal' OR actor_id={actor:UInt64})"
    return where, params


async def requests(store, view, filters):
    where, params = visibility_filter(view)
    where += " AND occurred_at>=now()-INTERVAL 90 DAY"
    limit = min(max(int(filters.get("limit", 50)), 1), 100)
    scope = ["api_requests", view, {k: v for k, v in filters.items() if k not in {"cursor", "limit"}}]
    for name, typ in [("key_id", "UUID"), ("status", "UInt16"), ("request_id", "UUID")]:
        if filters.get(name) is not None:
            params[name] = filters[name]
            where += f" AND {name}={{{name}:{typ}}}"
    if filters.get("cursor"):
        cursor = store.decode_cursor(filters["cursor"], scope)
        params.update(at=cursor["at"], id=cursor["id"])
        where += " AND (occurred_at,request_id)<({at:DateTime64(6)},{id:UUID})"
    params["limit"] = limit + 1
    rows = await store.sql(
        f"SELECT * EXCEPT version FROM api_requests FINAL WHERE {where} "
        "ORDER BY occurred_at DESC,request_id DESC LIMIT {limit:UInt32} FORMAT JSON",
        params,
    )
    token = None
    if len(rows) > limit:
        last = rows[limit - 1]
        token = store.cursor(
            {"context": scope, "expires": time.time() + 3600, "at": last["occurred_at"], "id": last["request_id"]}
        )
    return {"items": rows[:limit], "next_cursor": token, "retention_days": 90}


async def daily(store, view):
    where, params = visibility_filter(view)
    where += " AND day>=today()-INTERVAL 13 MONTH"
    return await store.sql(
        "SELECT day,sum(requests) AS requests,sum(errors) AS errors,sum(log_events) AS log_events,"
        f"sum(log_bytes) AS log_bytes FROM api_daily FINAL WHERE {where} "
        "GROUP BY day ORDER BY day DESC LIMIT 400 FORMAT JSON",
        params,
    )


async def rollup(store):
    # Rebuild only complete UTC days with raw data. Replacements make outbox retries idempotent.
    await store.sql(
        "INSERT INTO api_daily SELECT toDate(occurred_at) AS day,workspace_id,key_id,key_type,actor_id,"
        "audience,transport,count(),countIf(status>=400 OR status=0),sum(request_bytes),sum(response_bytes),"
        "sum(log_events),sum(log_bytes),toUInt64(toUnixTimestamp64Milli(now64(3))) "
        "FROM api_requests FINAL WHERE occurred_at>=today()-89 GROUP BY day,workspace_id,key_id,key_type,actor_id,audience,transport"
    )

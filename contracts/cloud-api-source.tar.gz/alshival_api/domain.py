import logging

import httpx

from .errors import APIError


class Domain:
    def __init__(self, settings):
        if not settings.service_secret:
            raise RuntimeError("ALSHIVAL_API_BRIDGE_SECRET is required")
        if not settings.bridge_socket and not settings.bridge_url.startswith("https://"):
            raise RuntimeError("Remote domain bridge requires HTTPS")
        self.client = httpx.AsyncClient(
            base_url=settings.bridge_url,
            timeout=70,
            transport=httpx.AsyncHTTPTransport(uds=settings.bridge_socket) if settings.bridge_socket else None,
            headers={"X-Service-Token": settings.service_secret},
            limits=httpx.Limits(max_connections=32),
        )

    async def call(self, operation, key=None, workspace_id=None, args=None, **extra):
        try:
            response = await self.client.post(
                "/bridge",
                json={"operation": operation, "key": key, "workspace_id": workspace_id, "args": args or {}, **extra},
            )
        except httpx.HTTPError as exc:
            logging.getLogger(__name__).warning(
                "Domain request failed operation=%s type=%s", operation, type(exc).__name__
            )

            raise APIError(503, "domain_unavailable", "Workspace service unavailable.", 5) from None
        import json

        from .usage import set_subject

        if response.headers.get("X-Alshival-Usage-Subject"):
            set_subject(json.loads(response.headers["X-Alshival-Usage-Subject"]))
        if response.is_error:
            try:
                data = response.json()
            except ValueError:
                data = {}
            code = response.status_code if response.status_code in (400, 401, 403, 404, 409, 413, 429) else 503
            raise APIError(
                code,
                data.get("error", "domain_unavailable"),
                data.get("message", "Workspace operation could not be completed."),
                5 if code == 503 else int(response.headers.get("Retry-After", "0")) or None,
                reset_at=data.get("reset_at"),
            )
        return response.json()

    async def close(self):
        await self.client.aclose()

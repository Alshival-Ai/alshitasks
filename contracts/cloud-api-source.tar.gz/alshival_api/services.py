"""Service creation is staff-only; resource attachment is independently authorized."""

import uuid
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ServiceCreate(BaseModel):
    lifecycle: Literal["planned", "active", "paused", "ended"] | None = None
    owner_id: int | None = Field(default=None, gt=0)
    modules: list[Literal["operations", "capacity", "support"]] | None = None
    model_config = ConfigDict(extra="forbid")
    idempotency_key: uuid.UUID
    name: str = Field(min_length=1, max_length=160)
    kind: Literal["website", "ai", "automation", "pipeline", "cloud", "retainer", "consulting", "development", "support", "other"] = "other"
    description: str = Field(default="", max_length=12000)
    public_url: str = Field(default="", max_length=200)
    active: bool | None = Field(default=None, strict=True)


class ServiceUpdate(BaseModel):
    lifecycle: Literal["planned", "active", "paused", "ended"] | None = None
    owner_id: int | None = Field(default=None, gt=0)
    modules: list[Literal["operations", "capacity", "support"]] | None = None
    model_config = ConfigDict(extra="forbid")
    idempotency_key: uuid.UUID
    expected_updated_at: str = Field(min_length=1, max_length=50)
    name: str | None = Field(default=None, min_length=1, max_length=160)
    kind: Literal["website", "ai", "automation", "pipeline", "cloud", "retainer", "consulting", "development", "support", "other"] | None = None
    description: str | None = Field(default=None, max_length=12000)
    public_url: str | None = Field(default=None, max_length=200)
    active: bool | None = Field(default=None, strict=True)


class TimeCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    idempotency_key: uuid.UUID
    occurred_at: str = Field(min_length=1, max_length=50)
    minutes: int = Field(gt=0, le=6000000, strict=True)
    description: str = Field(min_length=1, max_length=1000)
    internal_notes: str = Field(default="", max_length=10000)
    task_id: uuid.UUID | None = None
    staff_id: int | None = Field(default=None, gt=0)
    chargeable: bool = Field(default=True, strict=True)
    state: Literal["draft", "posted"] = "posted"


class TimeCorrect(BaseModel):
    model_config = ConfigDict(extra="forbid")
    idempotency_key: uuid.UUID
    revision: int = Field(ge=1, strict=True)
    reason: str = Field(min_length=1, max_length=1000)
    occurred_at: str | None = Field(default=None, max_length=50)
    minutes: int | None = Field(default=None, gt=0, le=6000000, strict=True)
    description: str | None = Field(default=None, min_length=1, max_length=1000)
    internal_notes: str | None = Field(default=None, max_length=10000)
    task_id: uuid.UUID | None = None
    staff_id: int | None = Field(default=None, gt=0)
    chargeable: bool | None = Field(default=None, strict=True)
    state: Literal["draft", "posted"] | None = None


class TimeVoid(BaseModel):
    model_config = ConfigDict(extra="forbid")
    idempotency_key: uuid.UUID
    revision: int = Field(ge=1, strict=True)
    reason: str = Field(min_length=1, max_length=1000)

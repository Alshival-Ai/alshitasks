"""Project board transport; authorization and workflow live in the website domain."""

import inspect
import uuid
from datetime import date
from typing import Annotated, Literal

from fastapi import Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field


class Input(BaseModel):
    board_id: uuid.UUID | None = None
    model_config = ConfigDict(extra="forbid")


class BoardCreate(Input):
    idempotency_key: uuid.UUID
    name: str = Field(min_length=1, max_length=120)


class BoardAction(Input):
    revision: int = Field(ge=1, strict=True)
    action: Literal["rename", "archive", "restore"]
    name: str | None = Field(default=None, min_length=1, max_length=120)


class TaskMove(Input):
    revision: int = Field(ge=1, strict=True)
    target_board_id: uuid.UUID
    target_status_id: uuid.UUID


class DeliverableCreate(Input):
    idempotency_key: uuid.UUID
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=6000)
    acceptance: str = Field(default="", max_length=4000)
    owner: int | None = Field(default=None, gt=0)
    starts_on: date | None = None
    due_on: date | None = None


class DeliverableUpdate(Input):
    revision: int = Field(ge=1, strict=True)
    title: str | None = Field(default=None, min_length=1, max_length=160)
    description: str | None = Field(default=None, max_length=6000)
    acceptance: str | None = Field(default=None, max_length=4000)
    owner: int | None = Field(default=None, gt=0)
    starts_on: date | None = None
    due_on: date | None = None


class TaskCreate(Input):
    type_id: uuid.UUID | None = None
    label_ids: list[uuid.UUID] | None = Field(default=None, max_length=100)
    status_id: uuid.UUID | None = None
    service: uuid.UUID | None = None
    idempotency_key: uuid.UUID
    title: str = Field(min_length=1, max_length=160)
    description: str = Field(default="", max_length=6000)
    acceptance: str = Field(default="", max_length=4000)
    deliverable: uuid.UUID | None = None
    source_ticket: uuid.UUID | None = None
    priority: Literal["low", "normal", "high", "urgent"] = "normal"
    assignee: int | None = Field(default=None, gt=0)
    reviewer: int | None = Field(default=None, gt=0)
    starts_on: date | None = None
    due_on: date | None = None


class TaskUpdate(Input):
    type_id: uuid.UUID | None = None
    label_ids: list[uuid.UUID] | None = Field(default=None, max_length=100)
    status_id: uuid.UUID | None = None
    service: uuid.UUID | None = None
    revision: int = Field(ge=1, strict=True)
    title: str | None = Field(default=None, min_length=1, max_length=160)
    description: str | None = Field(default=None, max_length=6000)
    acceptance: str | None = Field(default=None, max_length=4000)
    deliverable: uuid.UUID | None = None
    source_ticket: uuid.UUID | None = None
    priority: Literal["low", "normal", "high", "urgent"] | None = None
    assignee: int | None = Field(default=None, gt=0)
    reviewer: int | None = Field(default=None, gt=0)
    starts_on: date | None = None
    due_on: date | None = None


class RevisionInput(Input):
    revision: int = Field(ge=1, strict=True)


class CommentCreate(Input):
    idempotency_key: uuid.UUID
    body: str = Field(min_length=1, max_length=4000)
    visibility: Literal["shared", "internal"] | None = None


class CommentUpdate(RevisionInput):
    body: str = Field(min_length=1, max_length=4000)


class NoteCreate(Input):
    idempotency_key: uuid.UUID
    title: str = Field(default="", max_length=120)
    body: str = Field(min_length=1, max_length=5000)
    color: Literal["yellow", "blue", "pink", "green", "orange", "purple", "teal", "gray"] = "yellow"
    visibility: Literal["shared", "internal"] | None = None


class NoteUpdate(Input):
    revision: int = Field(ge=1, strict=True)
    title: str | None = Field(default=None, max_length=120)
    body: str | None = Field(default=None, min_length=1, max_length=5000)
    color: Literal["yellow", "blue", "pink", "green", "orange", "purple", "teal", "gray"] | None = None
    visibility: Literal["shared", "internal"] | None = None


class TicketCreate(Input):
    idempotency_key: uuid.UUID
    subject: str = Field(min_length=1, max_length=160)
    body: str = Field(min_length=1, max_length=20000)
    category: Literal["general", "technical", "billing", "change"] = "general"
    resource: uuid.UUID | None = None
    service: uuid.UUID | None = None


class Reply(Input):
    idempotency_key: uuid.UUID
    body: str = Field(min_length=1, max_length=20000)
    visibility: Literal["shared", "internal"] | None = None


class Action(Input):
    status_id: uuid.UUID | None = None
    revision: int = Field(ge=1, strict=True)
    action: Literal["work", "claim", "approve", "changes", "state", "reopen", "archive", "restore", "update"]
    state: str | None = Field(default=None, max_length=20)
    body: str = Field(default="", max_length=3000)
    blocked_reason: str = Field(default="", max_length=500)
    assignee: int | None = Field(default=None, gt=0)
    priority: Literal["low", "normal", "high", "urgent"] | None = None


class BoardConfigure(Input):
    revision: str = Field(min_length=64, max_length=64)
    action: Literal["create", "update", "default", "reorder", "retire"]
    status_id: uuid.UUID | None = None
    name: str | None = Field(default=None, min_length=1, max_length=60)
    category: Literal["todo", "doing", "done"] | None = None
    color: Literal["gray", "blue", "orange", "purple", "green", "pink", "teal"] | None = None
    status_ids: list[uuid.UUID] | None = None
    replacement_id: uuid.UUID | None = None


class TaxonomyConfigure(Input):
    revision: str = Field(min_length=64, max_length=64)
    kind: Literal["type", "label"]
    operation: Literal["create", "update", "archive", "default", "reorder"]
    id: uuid.UUID | None = None
    name: str | None = Field(default=None, min_length=1, max_length=60)
    icon: Literal["task", "bug", "story", "improvement", "research", "design", "support", "maintenance"] | None = None
    order: list[uuid.UUID] | None = None


def register_project_routes(app, call, Cred):
    prefix = "/v1/workspaces/{workspace_id}"

    def read_endpoint(operation, item=False):
        async def endpoint(
            request: Request,
            workspace_id: uuid.UUID,
            credential: Cred,
            item_id: uuid.UUID | None = None,
            board_id: uuid.UUID | None = None,
            cursor: str | None = None,
            limit: int = Query(50, ge=1, le=100),
            q: str | None = Query(None, max_length=160),
            state: str | None = None,
            status_id: uuid.UUID | None = None,
            type_ids: Annotated[list[uuid.UUID] | None, Query()] = None,
            label_ids: Annotated[list[uuid.UUID] | None, Query()] = None,
            archived: bool = False,
            deleted: bool = False,
            assignee_id: int | None = Query(None, gt=0),
            unassigned: bool = False,
            priority: Literal["low", "normal", "high", "urgent"] | None = None,
            due_before: date | None = None,
            due_after: date | None = None,
            kind: Literal["task", "service_ticket"] | None = None,
            deliverable_id: uuid.UUID | None = None,
        ):
            return await call(
                request,
                credential,
                "project:" + operation,
                workspace_id,
                {
                    "board_id": str(board_id) if board_id else None,
                    "id": str(item_id) if item_id else None,
                    "cursor": cursor,
                    "limit": limit,
                    "q": q,
                    "state": state,
                    "status_id": str(status_id) if status_id else None,
                    "type_ids": [str(i) for i in type_ids] if type_ids else [],
                    "label_ids": [str(i) for i in label_ids] if label_ids else [],
                    "archived": archived,
                    "deleted": deleted,
                    "assignee_id": assignee_id,
                    "unassigned": unassigned,
                    "priority": priority,
                    "due_before": due_before.isoformat() if due_before else None,
                    "due_after": due_after.isoformat() if due_after else None,
                    "kind": kind,
                    "deliverable_id": str(deliverable_id) if deliverable_id else None,
                },
            )

        endpoint.__name__ = "project_" + operation
        if not item:
            signature = inspect.signature(endpoint)
            endpoint.__signature__ = signature.replace(
                parameters=[p for name, p in signature.parameters.items() if name != "item_id"]
            )
        return endpoint

    def write_endpoint(operation, schema, creation=False, item=False):
        async def endpoint(
            request: Request,
            workspace_id: uuid.UUID,
            credential: Cred,
            data: schema,
            item_id: uuid.UUID | None = None,
        ):
            args = data.model_dump(mode="json", exclude_unset=True)
            if item_id:
                args["id"] = str(item_id)
            result = await call(request, credential, "project:" + operation, workspace_id, args)
            return JSONResponse(result["item"], status_code=201 if creation and result["created"] else 200)

        endpoint.__name__ = "project_" + operation
        if not item:
            signature = inspect.signature(endpoint)
            endpoint.__signature__ = signature.replace(
                parameters=[p for name, p in signature.parameters.items() if name != "item_id"]
            )
        return endpoint

    app.add_api_route(prefix + "/project/boards", read_endpoint("board_list"), methods=["GET"], tags=["Project board"])
    app.add_api_route(prefix + "/project/boards", write_endpoint("board_create", BoardCreate, True), methods=["POST"], tags=["Project board"])
    app.add_api_route(prefix + "/project/boards/{item_id}", write_endpoint("board_action", BoardAction, item=True), methods=["POST"], tags=["Project board"])
    app.add_api_route(prefix + "/tasks/{item_id}/move", write_endpoint("task_move", TaskMove, item=True), methods=["POST"], tags=["Project board"])
    for path, operation in [
        ("project/taxonomy", "task_taxonomy"),
        ("project/statuses", "board_statuses"),
        ("project", "board"),
        ("project/timeline", "timeline"),
        ("project/activity", "activity"),
        ("project/assignees", "assignees"),
    ]:
        app.add_api_route(prefix + "/" + path, read_endpoint(operation), methods=["GET"], tags=["Project board"])
    app.add_api_route(prefix + "/project/taxonomy", write_endpoint("taxonomy_configure", TaxonomyConfigure), methods=["POST"], tags=["Project board"])
    app.add_api_route(prefix + "/project/statuses", write_endpoint("board_configure", BoardConfigure), methods=["POST"], tags=["Project board"])
    for plural, kind, create, update in [
        ("deliverables", "deliverable", DeliverableCreate, DeliverableUpdate),
        ("tasks", "task", TaskCreate, TaskUpdate),
        ("notes", "note", NoteCreate, NoteUpdate),
        ("tickets", "ticket", TicketCreate, None),
    ]:
        path = prefix + "/" + plural
        app.add_api_route(path, read_endpoint(kind + "_list"), methods=["GET"], tags=["Project board"])
        app.add_api_route(
            path + "/{item_id}", read_endpoint(kind + "_get", item=True), methods=["GET"], tags=["Project board"]
        )
        app.add_api_route(
            path,
            write_endpoint(kind + "_create", create, True),
            methods=["POST"],
            status_code=201,
            responses={200: {"description": "Idempotent replay"}},
            tags=["Project board"],
        )
        if update:
            app.add_api_route(
                path + "/{item_id}",
                write_endpoint(kind + "_update", update, item=True),
                methods=["PATCH"],
                tags=["Project board"],
            )
        app.add_api_route(
            path + "/{item_id}/actions",
            write_endpoint(kind + "_action", Action, item=True),
            methods=["POST"],
            tags=["Project board"],
        )
    for kind, plural, collection, operation in [
        ("note", "notes", "replies", "reply"),
        ("ticket", "tickets", "messages", "message"),
    ]:
        path = prefix + "/" + plural + "/{item_id}/" + collection
        app.add_api_route(
            path, read_endpoint(kind + "_" + collection, item=True), methods=["GET"], tags=["Project board"]
        )
        app.add_api_route(
            path,
            write_endpoint(kind + "_" + operation, Reply, True, item=True),
            methods=["POST"],
            status_code=201,
            responses={200: {"description": "Idempotent replay"}},
            tags=["Project board"],
        )

    task_path = prefix + "/tasks/{item_id}"
    for suffix, operation, method in [("", "delete", "DELETE"), ("/restore", "restore_deleted", "POST")]:
        app.add_api_route(
            task_path + suffix,
            write_endpoint("task_" + operation, RevisionInput, item=True),
            methods=[method],
            tags=["Project board"],
        )
    app.add_api_route(
        task_path + "/comments", read_endpoint("task_comments", item=True), methods=["GET"], tags=["Project board"]
    )
    app.add_api_route(
        task_path + "/comments",
        write_endpoint("task_comment", CommentCreate, True, item=True),
        methods=["POST"],
        status_code=201,
        tags=["Project board"],
    )

    def comment_endpoint(operation, schema):
        async def endpoint(
            request: Request,
            workspace_id: uuid.UUID,
            item_id: uuid.UUID,
            comment_id: uuid.UUID,
            credential: Cred,
            data: schema,
        ):
            args = data.model_dump(mode="json", exclude_unset=True)
            args.update(id=str(item_id), comment_id=str(comment_id))
            result = await call(request, credential, "project:" + operation, workspace_id, args)
            return result["item"]

        endpoint.__name__ = "project_" + operation
        return endpoint

    app.add_api_route(
        task_path + "/comments/{comment_id}",
        comment_endpoint("task_comment_update", CommentUpdate),
        methods=["PATCH"],
        tags=["Project board"],
    )
    app.add_api_route(
        task_path + "/comments/{comment_id}",
        comment_endpoint("task_comment_delete", RevisionInput),
        methods=["DELETE"],
        tags=["Project board"],
    )

import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    bridge_url: str = field(default_factory=lambda: os.getenv("BRIDGE_URL", "http://domain"))
    bridge_socket: str = field(default_factory=lambda: os.getenv("BRIDGE_SOCKET", "/run/alshival-api/domain.sock"))
    service_secret: str = field(default_factory=lambda: os.getenv("ALSHIVAL_API_BRIDGE_SECRET", ""))
    clickhouse_url: str = field(default_factory=lambda: os.getenv("CLICKHOUSE_URL", "http://clickhouse:8123"))
    clickhouse_user: str = field(default_factory=lambda: os.getenv("CLICKHOUSE_USER", "alshival"))
    clickhouse_password: str = field(default_factory=lambda: os.getenv("CLICKHOUSE_PASSWORD", ""))
    redis_url: str = field(default_factory=lambda: os.getenv("REDIS_URL", "redis://redis:6379/0"))
    cursor_secret: str = field(default_factory=lambda: os.getenv("CURSOR_SECRET", ""))
    host_budget: int = field(default_factory=lambda: int(os.getenv("HOST_LOG_BUDGET_BYTES", "100000000000")))
    usage_path: str = field(default_factory=lambda: os.getenv("API_USAGE_PATH", "/var/lib/alshival-api/usage.sqlite3"))
    key_events_per_second: int = 1000
    workspace_events_per_second: int = 2000

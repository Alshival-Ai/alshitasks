import asyncio
import hashlib
import json
import logging
import re
import secrets
import time
import uuid
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from typing import Annotated, Literal

from fastapi import FastAPI, Query, Request, Security
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, ConfigDict, Field, ValidationError
from starlette.exceptions import HTTPException

from . import usage
from .config import Settings
from .domain import Domain
from .errors import APIError
from .events import Batch, normalize, otlp_events, read_body
from .limits import Limits
from .projects import register_project_routes
from .resources import ExternalID, ResourceCreate, ResourceSSHKeySet, ResourceUpdate
from .services import ServiceCreate, ServiceUpdate, TimeCorrect, TimeCreate, TimeVoid
from .store import Store

bearer = HTTPBearer(auto_error=False)


class AlertValues(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation_id: uuid.UUID
    id: uuid.UUID | None = None
    incident_id: uuid.UUID | None = None
    revision: int | None = Field(None, ge=0)
    label: str | None = Field(None, max_length=100)
    channel: Literal['email', 'sms', 'webhook', 'slack', 'discord'] | None = None
    address: str | None = Field(None, max_length=2048)
    shared: bool | None = None
    enabled: bool | None = None
    paused: bool | None = None
    consent: bool | None = None
    code: str | None = Field(None, max_length=64)
    action: Literal['subscribe', 'defaults', 'unsubscribe'] | None = None
    channels: dict[str, Literal['on', 'off', '']] | None = None
    configuration: dict | None = None


class AlertChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    operation: Literal['subscribe', 'policy', 'save_destination', 'request_verification', 'verify_destination',
                       'pause_destination', 'remove_destination', 'test', 'save_route', 'pause_route', 'acknowledge']
    values: AlertValues


class MonitorChange(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: uuid.UUID | None = None
    name: str | None = Field(None, min_length=1, max_length=100)
    kind: Literal['https', 'tcp', 'icmp', 'postgresql', 'mysql', 'mariadb', 'redis', 'mongodb', 'heartbeat'] | None = None
    location: Literal['public', 'neura', 'collector', 'heartbeat'] | None = None
    configuration: dict | None = None
    source_id: uuid.UUID | None = None
    credential: dict | None = None
    enabled: bool | None = None
    required: bool | None = None
    maintenance_until: datetime | None = None


class MonitorSubscription(BaseModel):
    model_config = ConfigDict(extra='forbid')
    action: Literal['defaults', 'save', 'unsubscribe']
    channels: dict[str, Literal['on', 'off']] = Field(default_factory=dict)


class MonitorSourceInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    action: Literal['enroll', 'revoke']
    name: str = Field('', max_length=100)
    kind: Literal['collector', 'heartbeat'] = 'collector'
    source_id: uuid.UUID | None = None


class FolderInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1, max_length=180)
    folder_id: uuid.UUID | None = None


class UploadInput(FolderInput):
    size: int = Field(ge=1, le=2_000_000_000, strict=True)
    idempotency_key: uuid.UUID
    replaces_id: uuid.UUID | None = None


class PartInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    number: int = Field(ge=1, le=10000, strict=True)
    checksum: str = Field(min_length=44, max_length=44)


def create_app(settings=None, domain=None, store=None, limits=None):
    settings = settings or Settings()

    @asynccontextmanager
    async def lifespan(app):
        if not settings.cursor_secret or not settings.service_secret:
            raise RuntimeError("Configure service and cursor secrets before starting the API")
        app.state.domain = domain or Domain(settings)
        app.state.store = store or Store(settings)
        app.state.limits = limits or Limits(settings)
        app.state.writes = asyncio.Semaphore(24)
        app.state.outbox = usage.Outbox(settings.usage_path if domain is None else ":memory:")
        await app.state.store.initialize()
        yield
        await app.state.domain.close()
        await app.state.store.close()
        await app.state.limits.close()
        app.state.outbox.close()

    app = FastAPI(
        title="Alshival workspace API",
        version="1.9.0",
        lifespan=lifespan,
        docs_url="/v1/docs",
        openapi_url="/v1/openapi.json",
        redoc_url=None,
        description="Workspace integration keys for projects, resources, services, and logs. Shared files live in Neural Labs.",
    )

    @app.middleware("http")
    async def request_context(request, call_next):
        started = time.perf_counter()
        request.state.request_id = str(uuid.uuid4())
        transport = (
            "mcp"
            if secrets.compare_digest(request.headers.get("X-Alshival-MCP-Token", ""), settings.service_secret)
            else "rest"
        )
        row = usage.new_row(request.state.request_id, request.method, transport)
        state = {"row": row, "outbox": request.app.state.outbox, "durable": False}
        original_receive = request._receive

        async def measured_receive():
            message = await original_receive()
            if message["type"] == "http.request":
                row["request_bytes"] += len(message.get("body", b""))
            return message

        request._receive = measured_receive
        token = usage.context.set(state)
        try:
            try:
                state["outbox"].save(row)
                state["durable"] = True
            except APIError:
                if request.method in {"POST", "PUT", "PATCH", "DELETE"} and re.match(
                    r"^/v1/workspaces/[^/]+/(resources|folders|uploads)(/|$)", request.url.path
                ):
                    raise
            if request.method in ("POST", "PUT", "PATCH") and "logs" not in request.url.path:
                raw = bytearray()
                async for chunk in request.stream():
                    raw.extend(chunk)
                    if len(raw) > 65536:
                        raise APIError(413, "request_too_large", "Metadata requests are limited to 64 KiB.")
                request._body = bytes(raw)
            response = await call_next(request)
        except APIError as exc:
            response = await api_error(request, exc)
        except Exception:
            logging.getLogger(__name__).exception("API request failed request_id=%s", row["request_id"])
            response = await api_error(
                request, APIError(500, "internal_error", "Request failed. Contact support with the request ID.")
            )
        finally:
            usage.context.reset(token)
        row["route"] = getattr(request.scope.get("route"), "path", "unmatched")
        row["status"] = response.status_code
        row["elapsed_ms"] = int((time.perf_counter() - started) * 1000)
        row["response_bytes"] = int(response.headers.get("content-length", 0))
        row["version"] = time.time_ns()
        if row["error_code"] == "outcome_unknown":
            row["error_code"] = "" if response.status_code < 400 else "request_failed"
        try:
            state["outbox"].save(row, done=True)
        except APIError:
            logging.getLogger(__name__).error("Usage finalization pending request_id=%s", row["request_id"])
        await request.app.state.limits.record(response.status_code, time.perf_counter() - started)
        response.headers.update(
            {"X-Request-ID": row["request_id"], "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"}
        )
        return response

    @app.exception_handler(APIError)
    async def api_error(request, exc):
        state = usage.context.get()
        if state:
            state["row"]["error_code"] = exc.code
        headers = {"Retry-After": str(exc.retry_after)} if exc.retry_after else {}
        return JSONResponse(
            {
                "error": {
                    "code": exc.code,
                    "message": exc.message,
                    **({"reset_at": exc.reset_at} if exc.reset_at else {}),
                },
                "request_id": request.state.request_id,
            },
            status_code=exc.status,
            headers=headers,
        )

    @app.exception_handler(HTTPException)
    async def http_error(request, exc):
        return await api_error(request, APIError(exc.status_code, "http_error", str(exc.detail)))

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, exc):
        return await api_error(
            request, APIError(400, "invalid_request", "Invalid request fields. Check the API schema.")
        )

    async def key_context(request, credential):
        if (
            not credential
            or credential.scheme.lower() != "bearer"
            or not credential.credentials.startswith(("alsh_ik_", "alsh_mk_", "alsh_pk_", "alsh_oa_"))
        ):
            raise APIError(401, "invalid_credentials", "A workspace integration Bearer key is required.")
        key = credential.credentials
        if len(key) > 160:
            raise APIError(401, "invalid_credentials", "Invalid credentials.")
        await request.app.state.limits.guard()
        workspace = str(request.path_params.get("workspace_id", ""))
        # Authenticate and resolve the workspace before attributing usage or charging its rate bucket.
        policy = await request.app.state.domain.call(
            "api_authorize" if workspace else "identity", key=key, workspace_id=workspace or None
        )
        internal_mcp = bool(settings.service_secret) and secrets.compare_digest(
            request.headers.get("X-Alshival-MCP-Token", ""), settings.service_secret
        )
        exempt = request.url.path in {
            "/v1/me", "/v1/workspaces"
        } or request.url.path.endswith(("/api-entitlements", "/api-usage", "/api-usage/requests"))
        if workspace and not internal_mcp and not exempt:
            await request.app.state.domain.call("api_consume", key=key, workspace_id=workspace)
        await request.app.state.limits.check(
            hashlib.sha256(key.encode()).hexdigest(),
            workspace,
            key_rate=policy.get("key_requests_per_second", 20),
            workspace_rate=policy.get("requests_per_second", 100),
        )
        return key

    async def call(request, credential, operation, workspace=None, args=None):
        key = await key_context(request, credential)
        return await request.app.state.domain.call(
            operation, key=key, workspace_id=str(workspace) if workspace else None, args=args
        )

    Cred = Annotated[HTTPAuthorizationCredentials | None, Security(bearer)]
    register_project_routes(app, call, Cred)

    @app.get("/v1/health", tags=["Operations"])
    async def health():
        return {"status": "ok"}

    @app.get("/v1/me", tags=["Identity"])
    async def identity(request: Request, credential: Cred):
        return await call(request, credential, "identity")

    prefix = "/v1/workspaces/{workspace_id}"

    @app.get(prefix + "/project-endpoint", tags=["Identity"],
             description="Resolve project storage and direct API/MCP endpoints. Requires project:read. Never proxies project content.")
    async def project_endpoint(request: Request, workspace_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "project_endpoint", workspace_id)

    @app.get("/v1/workspaces", tags=["Identity"])
    async def workspaces(request: Request, credential: Cred):
        return await call(request, credential, "workspaces")

    @app.get(
        prefix + "/api-entitlements", tags=["Usage"], description="Requires usage:read. Accepted effective API terms."
    )
    async def entitlements(request: Request, workspace_id: uuid.UUID, credential: Cred):
        result = await call(request, credential, "api_entitlements", workspace_id)
        result.pop("visibility", None)
        return result

    @app.get(
        prefix + "/api-usage",
        tags=["Usage"],
        description="Requires usage:read. Native consumption and visible daily request totals.",
    )
    async def api_usage(request: Request, workspace_id: uuid.UUID, credential: Cred):
        result = await call(request, credential, "api_usage", workspace_id)
        view = result.pop("visibility")
        result["daily"] = await usage.daily(request.app.state.store, view)
        policies = await request.app.state.domain.call(
            "api_authorize", key=credential.credentials, workspace_id=str(workspace_id)
        )
        result["retained_logs"] = await request.app.state.store.retained(str(workspace_id), policies)
        return result

    @app.get(
        prefix + "/api-usage/requests",
        tags=["Usage"],
        description="Requires usage:read and request-history permission. No bodies, credentials, or raw URLs are recorded.",
    )
    async def api_requests(
        request: Request,
        workspace_id: uuid.UUID,
        credential: Cred,
        limit: int = Query(50, ge=1, le=100),
        cursor: str | None = None,
        key_id: uuid.UUID | None = None,
        request_id: uuid.UUID | None = None,
        status: int | None = Query(None, ge=0, le=599),
    ):
        result = await call(request, credential, "api_usage_requests", workspace_id)
        return await usage.requests(
            request.app.state.store,
            result["visibility"],
            {
                "limit": limit,
                "cursor": cursor,
                "key_id": str(key_id) if key_id else None,
                "request_id": str(request_id) if request_id else None,
                "status": status,
            },
        )

    @app.post("/internal/usage/query", include_in_schema=False)
    async def session_usage(request: Request):
        if not secrets.compare_digest(request.headers.get("X-Service-Token", ""), settings.service_secret):
            raise APIError(401, "invalid_credentials", "Invalid service credentials.")
        data = await request.json()
        result = await request.app.state.domain.call(
            "user_usage", workspace_id=data["workspace_id"], user_id=data["user_id"], history=bool(data.get("history"))
        )
        view = result.pop("visibility")
        if data.get("history"):
            return await usage.requests(request.app.state.store, view, data.get("filters", {}))
        result["daily"] = await usage.daily(request.app.state.store, view)
        result["retained_logs"] = await request.app.state.store.retained(data["workspace_id"], result.pop("policy"))
        return result

    @app.get(prefix + "/agent-context", tags=["Identity"])
    async def agent_context(request: Request, workspace_id: uuid.UUID, credential: Cred):
        if request.query_params:
            raise APIError(400, "invalid_request", "The workspace briefing takes no query arguments.")
        return await call(request, credential, "agent_context", workspace_id)

    @app.get(prefix + "/resources", tags=["Resources"])
    async def resources(
        request: Request,
        workspace_id: uuid.UUID,
        credential: Cred,
        cursor: str | None = None,
        limit: int = Query(50, ge=1, le=100),
        external_id: ExternalID | None = None,
    ):
        return await call(
            request,
            credential,
            "resources",
            workspace_id,
            {"cursor": cursor, "limit": limit, "external_id": external_id},
        )

    @app.post(
        prefix + "/resources",
        status_code=201,
        tags=["Resources"],
        responses={
            200: {"description": "Identical registration already exists"},
            409: {"description": "External ID conflict"},
        },
        description="Requires resources:write and all-resource access. A stable external_id prevents duplicate registration.",
    )
    async def create_resource(
        request: Request,
        workspace_id: uuid.UUID,
        credential: Cred,
        data: ResourceCreate,
    ):
        result = await call(request, credential, "resource_create", workspace_id, data.model_dump(mode="json"))
        return JSONResponse(result["resource"], status_code=201 if result["created"] else 200)

    @app.patch(
        prefix + "/resources/{resource_id}",
        tags=["Resources"],
        description="Requires resources:write for this resource. Set status to retired to preserve its record and retained logs.",
    )
    async def update_resource(
        request: Request,
        workspace_id: uuid.UUID,
        resource_id: uuid.UUID,
        credential: Cred,
        data: ResourceUpdate,
    ):
        result = await call(
            request,
            credential,
            "resource_update",
            workspace_id,
            {"id": str(resource_id), **data.model_dump(mode="json", exclude_unset=True)},
        )
        return result["resource"]

    @app.get(prefix + '/resources/{resource_id}/alerts', tags=['Resources'])
    async def resource_alerts_read(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred):
        return await call(request, credential, 'resource_alerts', workspace_id, {'id': str(resource_id), 'operation': 'status'})

    @app.post(prefix + '/resources/{resource_id}/alerts', tags=['Resources'])
    async def resource_alerts_write(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID,
                                   credential: Cred, data: AlertChange):
        return await call(request, credential, 'resource_alerts', workspace_id, {'id': str(resource_id),
            'operation': data.operation, 'values': data.values.model_dump(mode='json', exclude_unset=True)})

    @app.get(prefix + '/resources/{resource_id}/monitoring', tags=['Resources'])
    async def monitoring_read(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred,
        view: Literal['status', 'history', 'incidents', 'deliveries'] = 'status'):
        return await call(request, credential, 'monitor', workspace_id, {'id': str(resource_id), 'operation': view})

    @app.post(prefix + '/resources/{resource_id}/monitoring', tags=['Resources'])
    async def monitoring_configure(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID,
        credential: Cred, data: MonitorChange):
        return await call(request, credential, 'monitor', workspace_id, {'id': str(resource_id), 'operation': 'configure',
            'values': data.model_dump(mode='json', exclude_unset=True)})

    @app.post(prefix + '/resources/{resource_id}/monitoring/subscription', tags=['Resources'])
    async def monitoring_subscription(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID,
        credential: Cred, data: MonitorSubscription):
        return await call(request, credential, 'monitor', workspace_id, {'id': str(resource_id), 'operation': 'subscribe',
            'values': data.model_dump(mode='json')})

    @app.post(prefix + '/resources/{resource_id}/monitoring/sources', tags=['Resources'])
    async def monitoring_source(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID,
        credential: Cred, data: MonitorSourceInput):
        return await call(request, credential, 'monitor', workspace_id, {'id': str(resource_id), 'operation': 'source',
            'values': data.model_dump(mode='json', exclude_unset=True)})

    @app.get(prefix + "/resources/{resource_id}/repository", tags=["Resources"])
    async def repository_read(
        request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred,
        view: Literal['status', 'tree', 'file', 'search', 'semantic'] = 'status',
        source: Literal['code', 'wiki'] = 'code', path: str = Query('', max_length=2000),
        query: str = Query('', max_length=1000), limit: int = Query(30, ge=1, le=100), line: int = Query(1, ge=1),
    ):
        return await call(request, credential, 'repository', workspace_id, {
            'id': str(resource_id), 'operation': view, 'source': source, 'path': path,
            'query': query, 'limit': limit, 'line': line,
        })

    @app.post(prefix + "/resources/{resource_id}/repository/refresh", tags=["Resources"])
    async def repository_refresh(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred):
        return await call(request, credential, 'repository', workspace_id, {'id': str(resource_id), 'operation': 'refresh'})

    @app.get(prefix + "/resources/{resource_id}", tags=["Resources"])
    async def resource(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred):
        result = await call(request, credential, "resource", workspace_id, {"id": str(resource_id)})
        return result["items"][0]

    @app.get(
        prefix + "/resources/{resource_id}/ssh-key",
        tags=["Resources"],
        description="Return Neura SSH alias, destination, fingerprint, and synchronization status. Key material is never returned.",
    )
    async def resource_ssh_key_status(
        request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred
    ):
        return await call(
            request, credential, "resource_ssh_status", workspace_id, {"resource_id": str(resource_id)}
        )

    @app.put(
        prefix + "/resources/{resource_id}/ssh-key",
        tags=["Resources"],
        description=("Install or rotate a write-only private key in the workspace's ready Neura runtime. "
                     "Send pasted key contents or read an uploaded local key file into private_key."),
    )
    async def set_resource_ssh_key(
        request: Request,
        workspace_id: uuid.UUID,
        resource_id: uuid.UUID,
        credential: Cred,
        data: ResourceSSHKeySet,
    ):
        return await call(
            request,
            credential,
            "resource_ssh_set",
            workspace_id,
            {"resource_id": str(resource_id), **data.model_dump(mode="json")},
        )

    @app.delete(
        prefix + "/resources/{resource_id}/ssh-key",
        tags=["Resources"],
        description="Remove the Neura SSH alias, private key, host trust entry, and destination firewall grant.",
    )
    async def remove_resource_ssh_key(
        request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred
    ):
        return await call(
            request, credential, "resource_ssh_remove", workspace_id, {"resource_id": str(resource_id)}
        )

    @app.get(prefix + "/services", tags=["Services"], description="Requires services:read.")
    async def services(
        request: Request,
        workspace_id: uuid.UUID,
        credential: Cred,
        q: str = Query("", max_length=160),
        cursor: str | None = None,
        limit: int = Query(50, ge=1, le=100),
    ):
        return await call(request, credential, "services", workspace_id, {"q": q, "cursor": cursor, "limit": limit})

    @app.get(prefix + "/services/{service_id}", tags=["Services"], description="Requires services:read.")
    async def service(request: Request, workspace_id: uuid.UUID, service_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "service", workspace_id, {"id": str(service_id)})

    @app.get(prefix + "/services/{service_id}/usage", tags=["Services"], description="Requires services:usage:read.")
    async def service_usage(
        request: Request,
        workspace_id: uuid.UUID,
        service_id: uuid.UUID,
        credential: Cred,
        cursor: str | None = None,
        limit: int = Query(50, ge=1, le=100),
    ):
        return await call(
            request,
            credential,
            "service_usage",
            workspace_id,
            {"service_id": str(service_id), "cursor": cursor, "limit": limit},
        )

    @app.post(
        prefix + "/services/{service_id}/time",
        tags=["Services"],
        description="Staff only: services:usage:write. Explicit actual minutes; never invoices automatically.",
    )
    async def service_time_create(
        request: Request, workspace_id: uuid.UUID, service_id: uuid.UUID, credential: Cred, data: TimeCreate
    ):
        return await call(
            request,
            credential,
            "service_time_create",
            workspace_id,
            {"service_id": str(service_id), **data.model_dump(mode="json", exclude_unset=True)},
        )

    @app.patch(
        prefix + "/services/{service_id}/time/{entry_id}",
        tags=["Services"],
        description="Staff only: services:usage:write. Revision and correction reason required.",
    )
    async def service_time_correct(
        request: Request,
        workspace_id: uuid.UUID,
        service_id: uuid.UUID,
        entry_id: uuid.UUID,
        credential: Cred,
        data: TimeCorrect,
    ):
        return await call(
            request,
            credential,
            "service_time_correct",
            workspace_id,
            {"service_id": str(service_id), "id": str(entry_id), **data.model_dump(mode="json", exclude_unset=True)},
        )

    @app.post(
        prefix + "/services/{service_id}/time/{entry_id}/void",
        tags=["Services"],
        description="Staff only: services:usage:write. Retains correction history.",
    )
    async def service_time_void(
        request: Request,
        workspace_id: uuid.UUID,
        service_id: uuid.UUID,
        entry_id: uuid.UUID,
        credential: Cred,
        data: TimeVoid,
    ):
        return await call(
            request,
            credential,
            "service_time_void",
            workspace_id,
            {"service_id": str(service_id), "id": str(entry_id), **data.model_dump(mode="json")},
        )

    @app.post(
        prefix + "/services",
        status_code=201,
        tags=["Services"],
        description="Requires a staff-audience key, services:write and the bound staff actor's live service permission. Creates a record, never billing.",
        responses={
            200: {"description": "Identical operation already completed"},
            409: {"description": "Idempotency conflict"},
        },
    )
    async def create_service(request: Request, workspace_id: uuid.UUID, credential: Cred, data: ServiceCreate):
        result = await call(
            request, credential, "service_create", workspace_id, data.model_dump(mode="json", exclude_unset=True)
        )
        return JSONResponse(result["item"], status_code=201 if result["created"] else 200)

    @app.patch(
        prefix + "/services/{service_id}",
        tags=["Services"],
        description="Staff only, services:write. Partial metadata edit; requires the latest updated_at and a reusable idempotency key.",
        responses={409: {"description": "Record changed or idempotency conflict"}},
    )
    async def update_service(
        request: Request, workspace_id: uuid.UUID, service_id: uuid.UUID, credential: Cred, data: ServiceUpdate
    ):
        result = await call(
            request,
            credential,
            "service_update",
            workspace_id,
            {"id": str(service_id), **data.model_dump(mode="json", exclude_unset=True)},
        )
        return result["item"]

    @app.put(
        prefix + "/resources/{resource_id}/services/{service_id}",
        tags=["Resources"],
        description="Add an existing service association. Requires resources:write, services:read, and access to the resource. Safe to retry; other associations are retained.",
    )
    async def attach_service(
        request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, service_id: uuid.UUID, credential: Cred
    ):
        return await call(
            request,
            credential,
            "resource_attach",
            workspace_id,
            {"resource_id": str(resource_id), "service_id": str(service_id)},
        )

    @app.get(prefix + "/folders", include_in_schema=False)
    async def folders(
        request: Request,
        workspace_id: uuid.UUID,
        credential: Cred,
        folder_id: uuid.UUID | None = None,
        cursor: str | None = None,
        limit: int = Query(50, ge=1, le=100),
    ):
        return await call(
            request,
            credential,
            "folders",
            workspace_id,
            {"folder_id": str(folder_id) if folder_id else None, "cursor": cursor, "limit": limit},
        )

    @app.post(prefix + "/folders", status_code=201, include_in_schema=False)
    async def new_folder(request: Request, workspace_id: uuid.UUID, credential: Cred, data: FolderInput):
        return await call(request, credential, "folder_create", workspace_id, data.model_dump(mode="json"))

    @app.get(prefix + "/files", include_in_schema=False)
    async def files(
        request: Request,
        workspace_id: uuid.UUID,
        credential: Cred,
        folder_id: uuid.UUID | None = None,
        cursor: str | None = None,
        limit: int = Query(50, ge=1, le=100),
    ):
        return await call(
            request,
            credential,
            "files",
            workspace_id,
            {"folder_id": str(folder_id) if folder_id else None, "cursor": cursor, "limit": limit},
        )

    @app.get(prefix + "/files/{file_id}/versions", include_in_schema=False)
    async def versions(
        request: Request,
        workspace_id: uuid.UUID,
        file_id: uuid.UUID,
        credential: Cred,
        cursor: str | None = None,
        limit: int = Query(50, ge=1, le=100),
    ):
        return await call(
            request, credential, "versions", workspace_id, {"id": str(file_id), "cursor": cursor, "limit": limit}
        )

    @app.get(prefix + "/documents/{document_id}", include_in_schema=False)
    async def document(request: Request, workspace_id: uuid.UUID, document_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "document", workspace_id, {"id": str(document_id)})

    @app.post(prefix + "/documents/{document_id}/download", include_in_schema=False)
    async def download(request: Request, workspace_id: uuid.UUID, document_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "download", workspace_id, {"id": str(document_id)})

    @app.post(prefix + "/uploads", status_code=201, include_in_schema=False)
    async def upload(request: Request, workspace_id: uuid.UUID, credential: Cred, data: UploadInput):
        return await call(request, credential, "upload_create", workspace_id, data.model_dump(mode="json"))

    @app.get(prefix + "/uploads/{upload_id}", include_in_schema=False)
    async def upload_status(request: Request, workspace_id: uuid.UUID, upload_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "upload_status", workspace_id, {"id": str(upload_id)})

    @app.post(prefix + "/uploads/{upload_id}/parts", include_in_schema=False)
    async def upload_part(
        request: Request, workspace_id: uuid.UUID, upload_id: uuid.UUID, credential: Cred, data: PartInput
    ):
        return await call(request, credential, "upload_part", workspace_id, {"id": str(upload_id), **data.model_dump()})

    @app.post(prefix + "/uploads/{upload_id}/complete", include_in_schema=False)
    async def upload_complete(request: Request, workspace_id: uuid.UUID, upload_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "upload_complete", workspace_id, {"id": str(upload_id)})

    @app.post(prefix + "/uploads/{upload_id}/abort", include_in_schema=False)
    async def upload_abort(request: Request, workspace_id: uuid.UUID, upload_id: uuid.UUID, credential: Cred):
        return await call(request, credential, "upload_abort", workspace_id, {"id": str(upload_id)})

    async def ingest(request, workspace, resource, credential, otlp=False):
        key = await key_context(request, credential)
        policy = await request.app.state.domain.call(
            "logs:write", key=key, workspace_id=str(workspace), args={"resource_id": str(resource)}
        )
        if request.app.state.writes.locked():
            raise APIError(503, "busy", "Log ingestion is busy; retry with backoff.", 1)
        async with request.app.state.writes:
            raw = await read_body(request)
            content_type = request.headers.get("content-type", "").split(";")[0]
            try:
                if otlp:
                    events = otlp_events(raw, content_type)
                else:
                    if content_type != "application/json":
                        raise APIError(415, "unsupported_type", "Use application/json.")
                    events = Batch.model_validate_json(raw).events
                now = datetime.now(UTC)
                normalized = normalize(events, now)
            except (ValidationError, ValueError, OverflowError, RecursionError):
                raise APIError(400, "invalid_events", "Invalid log fields. Check the batch schema.") from None
            await request.app.state.limits.check(policy["key_id"], str(workspace), len(events))
            await request.app.state.store.host_capacity()
            identifier = request.state.request_id
            if policy.get("hard_limit"):
                retained = await request.app.state.store.retained(str(workspace), policy)
                admission = await request.app.state.domain.call(
                    "logs:reserve",
                    key=key,
                    workspace_id=str(workspace),
                    args={
                        "id": identifier,
                        "resource_id": str(resource),
                        "bytes": sum(n for _, n in normalized),
                        "events": len(events),
                        **retained,
                    },
                )
                if admission["state"] != "reserved":
                    raise APIError(409, "admission_finalized", "This request was already finalized.")
                await request.app.state.store.insert(
                    str(workspace), str(resource), policy["key_id"], normalized, now, batch_id=identifier
                )
                try:
                    await request.app.state.domain.call("usage_finish", id=identifier, state="committed")
                except APIError:
                    logging.getLogger(__name__).warning("Log admission awaits reconciliation request_id=%s", identifier)
            else:
                await request.app.state.store.insert(str(workspace), str(resource), policy["key_id"], normalized, now)
            state = usage.context.get()
            state["row"].update(log_events=len(events), log_bytes=sum(n for _, n in normalized))
            if otlp:
                return Response(b"" if content_type == "application/x-protobuf" else b"{}", media_type=content_type)
            return {"accepted": len(events), "request_id": request.state.request_id}

    @app.post(
        prefix + "/resources/{resource_id}/logs",
        tags=["Logs"],
        openapi_extra={
            "requestBody": {"required": True, "content": {"application/json": {"schema": Batch.model_json_schema()}}}
        },
    )
    async def logs_ingest(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred):
        return await ingest(request, workspace_id, resource_id, credential)

    @app.post(
        prefix + "/resources/{resource_id}/otlp/v1/logs",
        tags=["Logs"],
        description="OTLP/HTTP ExportLogsServiceRequest, application/x-protobuf or application/json; gzip supported.",
    )
    async def otlp_ingest(request: Request, workspace_id: uuid.UUID, resource_id: uuid.UUID, credential: Cred):
        return await ingest(request, workspace_id, resource_id, credential, otlp=True)

    @app.get(prefix + "/resources/{resource_id}/logs", tags=["Logs"])
    async def logs_query(
        request: Request,
        workspace_id: uuid.UUID,
        resource_id: uuid.UUID,
        credential: Cred,
        cursor: str | None = None,
        limit: int = Query(100, ge=1, le=200),
        start: datetime | None = None,
        end: datetime | None = None,
        severity: str | None = Query(None, pattern="^(TRACE|DEBUG|INFO|WARN|ERROR|FATAL)$"),
        q: str | None = Query(None, max_length=500),
        trace_id: str | None = Query(None, pattern="^[0-9a-f]{32}$"),
    ):
        policy = await call(request, credential, "logs:read", workspace_id, {"resource_id": str(resource_id)})
        return await request.app.state.store.query(
            str(workspace_id),
            str(resource_id),
            policy,
            {
                k: v
                for k, v in {
                    "cursor": cursor,
                    "limit": limit,
                    "start": start.isoformat() if start else None,
                    "end": end.isoformat() if end else None,
                    "severity": severity,
                    "q": q,
                    "trace_id": trace_id,
                }.items()
                if v is not None
            },
        )

    @app.get("/internal/status", include_in_schema=False)
    async def status(request: Request):
        if not secrets.compare_digest(request.headers.get("X-Service-Token", ""), settings.service_secret):
            raise APIError(401, "invalid_credentials", "Invalid service credentials.")
        tables = await request.app.state.store.sql(
            "SELECT table,sum(rows) AS rows,sum(bytes_on_disk) AS disk_bytes,"
            "sum(data_uncompressed_bytes) AS uncompressed_bytes FROM system.parts WHERE active AND database='default' GROUP BY table FORMAT JSON"
        )
        mutations = await request.app.state.store.sql(
            "SELECT table,count() AS pending FROM system.mutations WHERE database='default' AND NOT is_done GROUP BY table FORMAT JSON"
        )
        return {
            "requests": await request.app.state.limits.metrics(),
            "usage_outbox": request.app.state.outbox.status(),
            "tables": tables,
            "pending_mutations": mutations,
            "host_budget_bytes": settings.host_budget,
        }

    @app.post("/internal/logs/query", include_in_schema=False)
    async def user_logs(request: Request):
        if not secrets.compare_digest(request.headers.get("X-Service-Token", ""), settings.service_secret):
            raise APIError(401, "invalid_credentials", "Invalid service credentials.")
        try:
            data = json.loads(await read_body(request))
            workspace, resource = str(uuid.UUID(data["workspace_id"])), str(uuid.UUID(data["resource_id"]))
            policy = await request.app.state.domain.call(
                "user_logs", workspace_id=workspace, resource_id=resource, user_id=int(data["user_id"])
            )
            return await request.app.state.store.query(workspace, resource, policy, data.get("filters", {}))
        except (ValueError, KeyError, TypeError):
            raise APIError(400, "invalid_request", "Invalid query.") from None

    from fastapi.openapi.utils import get_openapi

    def openapi():
        if app.openapi_schema is None:
            schema = get_openapi(title=app.title, version=app.version, description=app.description, routes=app.routes)
            batch = Batch.model_json_schema(ref_template="#/components/schemas/{model}")
            schema.setdefault("components", {}).setdefault("schemas", {}).update(batch.pop("$defs", {}))
            schema["components"]["schemas"]["Batch"] = batch
            schema["paths"][prefix + "/resources/{resource_id}/logs"]["post"]["requestBody"]["content"][
                "application/json"
            ]["schema"] = {"$ref": "#/components/schemas/Batch"}
            app.openapi_schema = schema
        return app.openapi_schema

    app.openapi = openapi
    return app


app = create_app()

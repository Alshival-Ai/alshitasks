"""Public resource registration and partial-update schemas."""

from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

ExternalID = Annotated[str, Field(min_length=1, max_length=200, pattern=r"^[A-Za-z0-9._:/@+\-]+$")]
Name = Annotated[str, Field(min_length=1, max_length=160)]
Kind = Literal["website", "server", "database", "api", "repository", "domain", "storage", "other"]
Status = Literal["planned", "active", "retired"]
Sticker = Literal["auto", "website", "server", "database", "api", "repository", "domain", "storage", "other"]
Tags = Annotated[list[Annotated[str, Field(min_length=1, max_length=40)]], Field(max_length=12)]
Details = Annotated[
    dict[Annotated[str, Field(min_length=1, max_length=120)], Annotated[str, Field(max_length=2000)]],
    Field(max_length=30, description="Workspace-visible labeled details. Typed keys: host, operating_system, service_ports (comma-separated ports), database_engine, database_name, database_port, database_tls (required or disabled). Never include credentials."),
]


class ResourceCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    external_id: ExternalID
    name: Name
    kind: Kind = "other"
    status: Status = "active"
    provider: str = Field(default="", max_length=120)
    environment: str = Field(default="", max_length=80)
    description: str = Field(default="", max_length=12000)
    public_url: str = Field(default="", max_length=200)
    details: Details = Field(default_factory=dict)
    sticker: Sticker = "auto"
    tags: Tags = Field(default_factory=list)


class ResourceUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: Name | None = None
    kind: Kind | None = None
    status: Status | None = None
    provider: str | None = Field(default=None, max_length=120)
    environment: str | None = Field(default=None, max_length=80)
    description: str | None = Field(default=None, max_length=12000)
    public_url: str | None = Field(default=None, max_length=200)
    details: Details | None = None
    sticker: Sticker | None = None
    tags: Tags | None = None

    @model_validator(mode="before")
    @classmethod
    def require_changes(cls, value):
        if not isinstance(value, dict) or not value or any(item is None for item in value.values()):
            raise ValueError("Provide at least one field; use empty strings or an empty details object to clear values.")
        return value


class ResourceSSHKeySet(BaseModel):
    """Write-only SSH key input. API responses never include these secret fields."""

    model_config = ConfigDict(extra="forbid")
    alias: str = Field(min_length=1, max_length=63, pattern=r"^[a-z][a-z0-9-]*$")
    host: str = Field(min_length=1, max_length=250)
    port: int = Field(default=22, ge=1, le=65535)
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_][A-Za-z0-9_.-]*$")
    private_key: str = Field(min_length=1, max_length=32768, repr=False)
    passphrase: str = Field(default="", max_length=1024, repr=False)

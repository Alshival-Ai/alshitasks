"""Durable log storage and monotonic, workspace-scoped retention cutoffs."""

import base64
import hashlib
import hmac
import json
import logging
import time
import uuid
from datetime import UTC, datetime, timedelta

import httpx

from .errors import APIError

SCHEMA = [
    """CREATE TABLE IF NOT EXISTS log_alert_acknowledgements (
      id UUID, acknowledged_at DateTime64(6, 'UTC')
    ) ENGINE = MergeTree ORDER BY id TTL toDateTime(acknowledged_at) + INTERVAL 91 DAY DELETE
    SETTINGS fsync_after_insert=1, fsync_part_directory=1""",
    """CREATE TABLE IF NOT EXISTS logs (
 workspace_id UUID, resource_id UUID, key_id UUID, received_at DateTime64(6, 'UTC'), batch_id UUID,
 id UUID, timestamp String, severity LowCardinality(String), message String,
 source String, attributes String, trace_id String, span_id String, normalized_bytes UInt64
) ENGINE = MergeTree PARTITION BY toYYYYMMDD(received_at)
ORDER BY (workspace_id, resource_id, received_at, batch_id, id)
TTL toDateTime(received_at) + INTERVAL 90 DAY DELETE
SETTINGS index_granularity=8192, fsync_after_insert=1, fsync_part_directory=1""",
    """CREATE TABLE IF NOT EXISTS log_batches (
 workspace_id UUID, received_at DateTime64(6, 'UTC'), batch_id UUID, bytes UInt64, events UInt64
) ENGINE = SummingMergeTree PARTITION BY toYYYYMMDD(received_at)
ORDER BY (workspace_id, received_at, batch_id)
TTL toDateTime(received_at) + INTERVAL 90 DAY DELETE
SETTINGS fsync_after_insert=1, fsync_part_directory=1""",
    """CREATE MATERIALIZED VIEW IF NOT EXISTS log_batch_view TO log_batches AS
SELECT workspace_id, received_at, batch_id, sum(normalized_bytes) AS bytes, count() AS events
FROM logs GROUP BY workspace_id, received_at, batch_id""",
    """CREATE TABLE IF NOT EXISTS retention_cutoffs (
 workspace_id UUID, received_at DateTime64(6, 'UTC'), batch_id UUID, updated_at DateTime64(6, 'UTC')
) ENGINE = MergeTree ORDER BY (workspace_id,received_at,batch_id) SETTINGS fsync_after_insert=1, fsync_part_directory=1""",
]
ZERO = "00000000-0000-0000-0000-000000000000"


def stamp(value):
    return value.astimezone(UTC).strftime("%Y-%m-%d %H:%M:%S.%f")


class Store:
    def __init__(self, settings):
        self.settings = settings
        self.client = httpx.AsyncClient(
            base_url=settings.clickhouse_url,
            timeout=20,
            auth=(settings.clickhouse_user, settings.clickhouse_password),
            limits=httpx.Limits(max_connections=32),
        )

    async def sql(self, query, params=None, content=None):
        parameters = {
            "database": "default",
            "max_execution_time": "15",
            "max_memory_usage": "536870912",
            "max_threads": "2",
            "log_queries": "0",
            "wait_end_of_query": "1",
            "query": query,
        }
        parameters.update({"param_" + key: str(value) for key, value in (params or {}).items()})
        try:
            response = await self.client.post("/", params=parameters, content=content)
            response.raise_for_status()
            return response.json().get("data", []) if query.rstrip().endswith("FORMAT JSON") else []
        except (httpx.HTTPError, ValueError) as exc:
            logging.getLogger(__name__).warning(
                "Storage request failed operation=%s type=%s status=%s",
                query.split()[0],
                type(exc).__name__,
                getattr(getattr(exc, "response", None), "status_code", None),
            )
            raise APIError(503, "logs_unavailable", "Log storage unavailable; retry with backoff.", 5) from None

    async def initialize(self):
        from .usage import SCHEMA as USAGE_SCHEMA

        for query in SCHEMA + USAGE_SCHEMA:
            await self.sql(query)
        for table in ("logs", "log_batches", "retention_cutoffs"):
            await self.sql(f"ALTER TABLE {table} MODIFY SETTING fsync_after_insert=1, fsync_part_directory=1")

    async def host_capacity(self):
        rows = await self.sql(
            "SELECT sum(bytes_on_disk) AS bytes FROM system.parts WHERE active AND database='default' FORMAT JSON"
        )
        if int(rows[0]["bytes"] or 0) >= self.settings.host_budget:
            raise APIError(503, "host_capacity", "Log storage is at capacity; retry later.", 30)
        disks = await self.sql("SELECT min(free_space) AS free FROM system.disks FORMAT JSON")
        if int(disks[0]["free"]) < 10_000_000_000:
            raise APIError(503, "host_capacity", "Log storage is at capacity; retry later.", 30)

    async def insert(self, workspace, resource, key, events, now, batch_id=None):
        if not events:
            return
        batch = batch_id or str(uuid.uuid4())
        rows = []
        for data, size in events:
            rows.append(
                {
                    **data,
                    "attributes": json.dumps(data["attributes"], ensure_ascii=False, allow_nan=False),
                    "workspace_id": workspace,
                    "resource_id": resource,
                    "key_id": key,
                    "received_at": stamp(now),
                    "batch_id": batch,
                    "id": str(uuid.uuid4()),
                    "normalized_bytes": size,
                }
            )
        # Acknowledgement waits for ClickHouse's durable insert and dependent materialized view.
        await self.sql(
            "INSERT INTO logs SETTINGS async_insert=1, wait_for_async_insert=1, async_insert_busy_timeout_ms=200 FORMAT JSONEachRow",
            content="\n".join(json.dumps(row, ensure_ascii=False, allow_nan=False) for row in rows).encode(),
        )

    async def alert_errors(self, since):
        # Scan persisted rows independently of ingestion acknowledgement. Durable acknowledgements
        # are the cursor, so late inserts cannot slip behind a timestamp watermark.
        return await self.sql(
            "SELECT toString(id) AS id, toString(workspace_id) AS workspace_id, "
            "toString(resource_id) AS resource_id, received_at, severity, substringUTF8(message, 1, 320) AS message FROM logs "
            "WHERE severity IN ('ERROR','FATAL') AND received_at >= {since:DateTime64(6)} "
            "AND id NOT IN (SELECT id FROM log_alert_acknowledgements) "
            "ORDER BY received_at,id LIMIT 100 FORMAT JSON", {'since': since})

    async def acknowledge_errors(self, ids):
        if ids:
            await self.sql('INSERT INTO log_alert_acknowledgements FORMAT JSONEachRow', content='\n'.join(
                json.dumps({'id': str(uuid.UUID(identifier)), 'acknowledged_at': stamp(datetime.now(UTC))})
                for identifier in ids).encode())

    async def cutoff(self, workspace, policy):
        floor = (stamp(datetime.now(UTC) - timedelta(days=policy["retention_days"])), ZERO)
        saved = await self.sql(
            "SELECT received_at, toString(batch_id) AS batch_id FROM retention_cutoffs "
            "WHERE workspace_id={ws:UUID} ORDER BY received_at DESC,batch_id DESC LIMIT 1 FORMAT JSON",
            {"ws": workspace},
        )
        if saved:
            floor = max(floor, (saved[0]["received_at"], saved[0]["batch_id"]))
        params = {"ws": workspace, "floor": floor[0], "batch": floor[1], "quota": policy["quota_bytes"]}
        total = await self.sql(
            "SELECT sum(bytes) AS bytes FROM log_batches WHERE workspace_id={ws:UUID} "
            "AND (received_at,batch_id)>=({floor:DateTime64(6)}, {batch:UUID}) FORMAT JSON",
            params,
        )
        # Only quota eviction moves the floor beyond age-based retention. An empty query must
        # never hide a concurrent insert that has not yet finished persisting.
        if policy.get("hard_limit") or policy["quota_bytes"] is None or int(total[0]["bytes"]) <= policy["quota_bytes"]:
            await self.save_cutoff(workspace, floor, saved)
            return floor
        # Batch summaries make quota enforcement independent of the number/size of log messages.
        rows = await self.sql(
            """SELECT received_at, toString(batch_id) AS batch_id FROM (
          SELECT received_at, batch_id, sum(bytes) OVER (ORDER BY received_at DESC, batch_id DESC ROWS UNBOUNDED PRECEDING) AS total
          FROM (SELECT received_at, batch_id, sum(bytes) AS bytes FROM log_batches
                WHERE workspace_id={ws:UUID} AND (received_at,batch_id)>=({floor:DateTime64(6)}, {batch:UUID})
                GROUP BY received_at,batch_id)
        ) WHERE total <= {quota:UInt64} ORDER BY received_at,batch_id LIMIT 1 FORMAT JSON""",
            params,
        )
        if rows:
            floor = max(floor, (rows[0]["received_at"], rows[0]["batch_id"]))
        else:
            newest = await self.sql(
                "SELECT received_at,batch_id FROM log_batches WHERE workspace_id={ws:UUID} "
                "ORDER BY received_at DESC,batch_id DESC LIMIT 1 FORMAT JSON",
                params,
            )
            if newest:
                received = datetime.fromisoformat(newest[0]["received_at"]).replace(tzinfo=UTC)
                floor = max(floor, (stamp(received + timedelta(microseconds=1)), ZERO))
        await self.save_cutoff(workspace, floor, saved)
        return floor

    async def save_cutoff(self, workspace, floor, saved):
        if not saved or floor > (saved[0]["received_at"], saved[0]["batch_id"]):
            await self.sql(
                "INSERT INTO retention_cutoffs FORMAT JSONEachRow",
                content=json.dumps(
                    {
                        "workspace_id": workspace,
                        "received_at": floor[0],
                        "batch_id": floor[1],
                        "updated_at": stamp(datetime.now(UTC)),
                    }
                ).encode(),
            )

    def cursor(self, value):
        raw = json.dumps(value, separators=(",", ":")).encode()
        sig = hmac.new(self.settings.cursor_secret.encode(), raw, hashlib.sha256).digest()
        return base64.urlsafe_b64encode(sig + raw).decode().rstrip("=")

    def decode_cursor(self, value, context):
        try:
            raw = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
            if not hmac.compare_digest(
                raw[:32], hmac.new(self.settings.cursor_secret.encode(), raw[32:], hashlib.sha256).digest()
            ):
                raise ValueError
            data = json.loads(raw[32:])
            if data["context"] != context or data["expires"] < time.time():
                raise ValueError
            return data
        except (ValueError, KeyError, TypeError):
            raise APIError(400, "invalid_cursor", "Invalid, expired, or mismatched cursor.") from None

    async def query(self, workspace, resource, policy, filters):
        floor = await self.cutoff(workspace, policy)
        limit = min(max(int(filters.get("limit", 100)), 1), 200)
        params = {"ws": workspace, "resource": resource, "floor": floor[0], "batch": floor[1], "limit": limit + 1}
        where = "workspace_id={ws:UUID} AND resource_id={resource:UUID} AND (received_at,batch_id)>=({floor:DateTime64(6)},{batch:UUID})"
        context = [workspace, resource, {k: v for k, v in filters.items() if k not in ("cursor", "limit")}]
        for name, operator in [("start", ">="), ("end", "<=")]:
            if filters.get(name):
                value = datetime.fromisoformat(filters[name])
                if value.tzinfo is None:
                    raise APIError(400, "invalid_time", "Time filters require a time zone.")
                params[name] = value.astimezone(UTC).isoformat()
                where += f" AND timestamp {operator} {{{name}:String}}"
        for field in ("severity", "trace_id"):
            if filters.get(field):
                params[field] = filters[field]
                where += f" AND {field}={{{field}:String}}"
        if filters.get("q"):
            params["q"] = filters["q"][:500]
            where += " AND positionCaseInsensitiveUTF8(message,{q:String})>0"
        upper = stamp(datetime.now(UTC))
        if filters.get("cursor"):
            cursor = self.decode_cursor(filters["cursor"], context)
            params.update({"cursor_time": cursor["time"], "cursor_id": cursor["id"]})
            upper = cursor["upper"]
            where += " AND (received_at,id)<({cursor_time:DateTime64(6)},{cursor_id:UUID})"
        params["upper"] = upper
        where += " AND received_at<={upper:DateTime64(6)}"
        rows = await self.sql(
            "SELECT id, received_at, timestamp, severity, message, source, attributes, trace_id, span_id "
            f"FROM logs WHERE {where} ORDER BY received_at DESC,id DESC LIMIT {{limit:UInt32}} FORMAT JSON",
            params,
        )
        token = None
        if len(rows) > limit:
            last = rows[limit - 1]
            token = self.cursor(
                {
                    "context": context,
                    "expires": time.time() + 3600,
                    "upper": upper,
                    "time": last["received_at"],
                    "id": last["id"],
                }
            )
        for row in rows:
            row["attributes"] = json.loads(row["attributes"])
        usage = await self.sql(
            "SELECT sum(bytes) AS bytes,sum(events) AS events,min(received_at) AS oldest "
            "FROM log_batches WHERE workspace_id={ws:UUID} AND (received_at,batch_id)>=({floor:DateTime64(6)},{batch:UUID}) FORMAT JSON",
            params,
        )
        return {
            "items": rows[:limit],
            "next_cursor": token,
            "retention": {
                "cutoff": floor[0],
                "retention_days": policy["retention_days"],
                "quota_bytes": policy["quota_bytes"],
                "used_bytes": int(usage[0]["bytes"]),
                "events": int(usage[0]["events"]),
                "oldest_received_at": usage[0]["oldest"] if int(usage[0]["events"]) else None,
            },
        }

    async def maintain(self, policy):
        workspace = policy["workspace_id"]
        floor = await self.cutoff(workspace, policy)
        for table in ("logs", "log_batches"):
            pending = await self.sql(
                "SELECT count() AS n FROM system.mutations WHERE database='default' "
                "AND table={table:String} AND NOT is_done FORMAT JSON",
                {"table": table},
            )
            if int(pending[0]["n"]) >= 32:
                continue
            obsolete = await self.sql(
                f"SELECT count() AS n FROM {table} WHERE workspace_id={{ws:UUID}} "
                "AND (received_at,batch_id)<({floor:DateTime64(6)},{batch:UUID}) FORMAT JSON",
                {"ws": workspace, "floor": floor[0], "batch": floor[1]},
            )
            if not int(obsolete[0]["n"]):
                continue
            await self.sql(
                f"ALTER TABLE {table} DELETE WHERE workspace_id={{ws:UUID}} "
                "AND (received_at,batch_id)<({floor:DateTime64(6)},{batch:UUID})",
                {"ws": workspace, "floor": floor[0], "batch": floor[1]},
            )

    async def retained(self, workspace, policy):
        observed = datetime.now(UTC).isoformat()
        floor = await self.cutoff(workspace, policy)
        rows = await self.sql(
            "SELECT sum(bytes) AS bytes FROM log_batches WHERE workspace_id={ws:UUID} "
            "AND (received_at,batch_id)>=({floor:DateTime64(6)},{batch:UUID}) FORMAT JSON",
            {"ws": workspace, "floor": floor[0], "batch": floor[1]},
        )
        return {"stored_bytes": int(rows[0]["bytes"]), "observed_at": observed}

    async def batch_outcome(self, workspace, identifier, *, events, size):
        """Keep ambiguous or partial writes reserved until both durable totals agree."""
        rows = await self.sql(
            "SELECT * FROM "
            "(SELECT count() AS log_events, sum(normalized_bytes) AS log_bytes FROM logs "
            "WHERE workspace_id={ws:UUID} AND batch_id={id:UUID}) AS primary_totals CROSS JOIN "
            "(SELECT sum(events) AS batch_events, sum(bytes) AS batch_bytes FROM log_batches "
            "WHERE workspace_id={ws:UUID} AND batch_id={id:UUID}) AS summary_totals FORMAT JSON",
            {"ws": workspace, "id": identifier},
        )
        totals = tuple(int(rows[0][key]) for key in ("log_events", "log_bytes", "batch_events", "batch_bytes"))
        if totals == (events, size, events, size):
            return True
        if totals == (0, 0, 0, 0):
            return False
        return None

    async def close(self):
        await self.client.aclose()

import time

from redis.asyncio import Redis
from redis.exceptions import RedisError

from .errors import APIError

# Atomic token buckets across workers/containers. No process-local rate-limit bypass.
BUCKET = """
local now = tonumber(ARGV[1])
for i,key in ipairs(KEYS) do
 local rate = tonumber(ARGV[2*i+1])
 local amount = tonumber(ARGV[2*i+2])
 local state = redis.call('HMGET',key,'tokens','at')
 local tokens = math.min(rate*2, tonumber(state[1] or rate*2)+(now-tonumber(state[2] or now))*rate)
 if tokens < amount then return 0 end
end
for i,key in ipairs(KEYS) do
 local rate = tonumber(ARGV[2*i+1])
 local amount = tonumber(ARGV[2*i+2])
 local state = redis.call('HMGET',key,'tokens','at')
 local tokens = math.min(rate*2, tonumber(state[1] or rate*2)+(now-tonumber(state[2] or now))*rate)-amount
 redis.call('HSET',key,'tokens',tokens,'at',now)
 redis.call('EXPIRE',key,60)
end
return 1
"""


class Limits:
    def __init__(self, settings):
        self.settings = settings
        self.redis = Redis.from_url(settings.redis_url, socket_timeout=2, socket_connect_timeout=2)

    async def guard(self):
        # Unverified credentials must not bypass the host's authentication budget.
        await self.admit(["api:host"], [time.time(), 0, 500, 1])

    async def check(self, key, workspace="", events=0, key_rate=20, workspace_rate=100):
        keys = ["api:key:" + key, "api:ws:" + workspace]
        args = [time.time(), 0, key_rate, 1, workspace_rate, 1]
        if events:
            keys, args = [], [time.time(), 0]
            keys += ["events:key:" + key, "events:ws:" + workspace, "events:host"]
            args += [
                self.settings.key_events_per_second,
                events,
                self.settings.workspace_events_per_second,
                events,
                5000,
                events,
            ]
        await self.admit(keys, args)

    async def admit(self, keys, args):
        try:
            allowed = await self.redis.eval(BUCKET, len(keys), *keys, *args)
        except RedisError:
            raise APIError(503, "limiter_unavailable", "API temporarily unavailable.", 5) from None
        if not allowed:
            raise APIError(429, "rate_limited", "Rate limit exceeded.", 1)

    async def close(self):
        await self.redis.aclose()

    async def record(self, status, elapsed):
        try:
            async with self.redis.pipeline(transaction=False) as pipe:
                pipe.hincrby("api:metrics", "requests", 1)
                pipe.hincrby("api:metrics", f"status_{status}", 1)
                pipe.hincrbyfloat("api:metrics", "duration_seconds_sum", elapsed)
                for bound in (0.1, 0.25, 0.5, 1, 2, 5, 15, 60):
                    if elapsed <= bound:
                        pipe.hincrby("api:metrics", f"duration_le_{bound}", 1)
                await pipe.execute()
        except RedisError:
            pass  # Metrics failures must not change an ingestion acknowledgement.

    async def metrics(self):
        try:
            return {k.decode(): float(v) for k, v in (await self.redis.hgetall("api:metrics")).items()}
        except RedisError:
            raise APIError(503, "metrics_unavailable", "Metrics temporarily unavailable.", 5) from None
